//
//  TDDSampleWikiTests.h
//  TDDSampleWikiTests
//
//  Created by Trinh Huy Cuong  on 5/24/13.
//  Copyright (c) 2013 QSoftVietNam. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@class Money;
@interface TDDSampleWikiTests : SenTestCase{
    Money *m;
    NSString *currentCurrency, *anotherCurrency;
}

@end
