//
//  ViewController.h
//  TDDSampleWiki
//
//  Created by Trinh Huy Cuong  on 5/24/13.
//  Copyright (c) 2013 QSoftVietNam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
