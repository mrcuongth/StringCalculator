//
//  SeverCommunication.m
//  TDDSampleWiki
//
//  Created by Trinh Huy Cuong  on 5/27/13.
//  Copyright (c) 2013 QSoftVietNam. All rights reserved.
//

#import "ServerCommunication.h"

@implementation ServerCommunication

- (NSNumber*) getExchangeRateOfCurrency:(NSString*)c1 andCurrency:(NSString*)c2{
    // Do something to get exchange rate
    return @1.5;
}


@end
