//
//  StackCollectionTest.m
//  TDDExample
//
//  Created by El Nino on 5/27/13.
//  Copyright (c) 2013 El Nino. All rights reserved.
//

#import "Kiwi.h"
#import "StackCollection.h"

SPEC_BEGIN(StackCollectionTest)
describe(@"StackCollection test", ^{
    // After refactor
    __block StackCollection *_instance = nil;
    
    beforeAll(^{
        
    });
    
    afterAll(^{
        _instance = nil;
    });
    
    beforeEach(^{
        _instance = [[StackCollection alloc] init];
    });
    
    afterEach(^{
        _instance = nil;
    });
    
    context(@"when creating a new collection", ^{
//        // Step 1
//        pending(@"the collection should exist", ^{
//            
//        });
        
//         // Step 2
//        it(@"the collection should exist", ^{
//            StackCollection *instance = [[StackCollection alloc] init];
//            [instance shouldNotBeNil];
//        });
        
        // Step 3
        it(@"the collection should exist", ^{
            [_instance shouldNotBeNil];
        });
    });
    
    context(@"pushing an object onto the stack", ^{
//        // Step 1
//        pending(@"the stack count should be one", ^{
//            
//        });
        
//        // Step 2
//        it(@"pushing an object onto the stack", ^{
//            StackCollection *instance = [[StackCollection alloc] init];
//            [instance push:@"Item 1"];
//            [[instance should] haveCountOf:1];
//        });
        
        // Step 3
        it(@"pushing an object onto the stack", ^{
            [_instance push:@"Item 1"];
            [[_instance should] haveCountOf:1];
        });
        
    });
    
    context(@"popping an object off of the stack", ^{
//        // Step 1
//        pending(@"the popped object should be the same as pushed", ^{
//            
//        });
        
//        // Step 2
//        it(@"the poped object should be the same as pushed", ^{
//            StackCollection *instance = [[StackCollection alloc] init];
//            NSString *pushObject = @"Item 1";
//            [instance push:pushObject];
//            
//            id popObject = [instance pop];
//            [[popObject should] equal:pushObject];
//            
//            [[instance should] beEmpty];
//        });
        
        // Step 3
        it(@"the poped object should be the same as pushed", ^{
            NSString *pushObject = @"Item 1";
            [_instance push:pushObject];
            
            id popObject = [_instance pop];
            [[popObject should] equal:pushObject];
            
            [[_instance should] beEmpty];
        });

    });
    
    context(@"the stack should contain at least 10 concurrent objects", ^{
//        // Step 1
//        pending(@"add objects, compare after popping and check stack count", ^{
//        });
//        
//        // Step 2
//        it(@"add 10 objects, compare after popping and check stack count", ^{
//            StackCollection *instance = [[StackCollection alloc] init];
//            for(int i = 0; i < 10; i ++) {
//                NSString *pushItem = [NSString stringWithFormat:@"Item %i", i];
//                [instance push:pushItem];
//            }
//            
//            for(int i = 9; i >= 0; i --) {
//                NSString *expectItem = [NSString stringWithFormat:@"Item %i", i];
//                NSString *popItem = [instance pop];
//                [[popItem should] equal:expectItem];
//            }
//            
//            [[instance should] beEmpty];
//        });
        
        // Step 3
        it(@"add 10 objects, compare after popping and check stack count", ^{
            for(int i = 0; i < 10; i ++) {
                NSString *pushItem = [NSString stringWithFormat:@"Item %i", i];
                [_instance push:pushItem];
            }
            
            for(int i = 9; i >= 0; i --) {
                NSString *expectItem = [NSString stringWithFormat:@"Item %i", i];
                NSString *popItem = [_instance pop];
                [[popItem should] equal:expectItem];
            }
            
            [[_instance should] beEmpty];
        });
    });

    
    context(@"peeking at the topmost object on the stack", ^{
//        // Step 1
//        pending(@"the peek object should be the same as the last pushed", ^{
//            
//        });
//        
//        pending(@"the stacks object count should be unaffected by peeking", ^{
//            
//        });
        
//        // Step 2
//        it(@"the peek object should be the same as the last push", ^{
//            StackCollection *instance = [[StackCollection alloc] init];
//            NSString *lastPushObject = @"Item 1";
//            [instance push:lastPushObject];
//            
//            NSString *peekObject = [instance peek];
//            [[peekObject should] equal:lastPushObject];
//        });
//        
//        it(@"the stacks object count should be unaffected by peeking", ^{
//            StackCollection *instance = [[StackCollection alloc] init];
//            [instance push:@"Item 1"];
//            [instance peek];
//            [[instance should] haveCountOf:1];
//        });
        
        // Step 3        
        __block NSString *lastPushObject;
        beforeEach(^{
            lastPushObject = @"Item 1";
            [_instance push:lastPushObject];
        });
        
        it(@"the peek object should be the same as the last push", ^{
            [_instance push:lastPushObject];
            
            NSString *peekObject = [_instance peek];
            [[peekObject should] equal:lastPushObject];
        });
        
        it(@"the stacks object count should be unaffected by peeking", ^{
            [_instance peek];
            [[_instance should] haveCountOf:1];
        });
    });
});
SPEC_END
