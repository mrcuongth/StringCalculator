//
//  StackCollection.m
//  TDDExample
//
//  Created by El Nino on 5/27/13.
//  Copyright (c) 2013 El Nino. All rights reserved.
//

#import "StackCollection.h"

@interface StackCollection()

@property (nonatomic, strong) NSMutableArray *collections;

@end

@implementation StackCollection

@synthesize collections = _collections;
@synthesize count = _count;

- (id)init
{
    self = [super init];
    if (self) {
        _collections = [[NSMutableArray alloc] init];
    }
    return self;
}

-(void)push:(id)object {
    [_collections addObject:object];
}

-(id)pop {
    id popObject = [_collections lastObject];
    [_collections removeLastObject];
    return popObject;
}

-(id)peek {
    id peekObject = [_collections lastObject];
    return peekObject;
}

-(NSUInteger)count {
    return [_collections count];
}

@end
